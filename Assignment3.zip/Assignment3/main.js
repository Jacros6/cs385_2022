
let gl = null;
let cube = null;

window.onload = function init() {
    var canvas = document.getElementById("webgl-canvas")
    gl = canvas.getContext("webgl2")
    if (!gl){
        alert ("WebGL 2.0 is not available")
    }

    gl.clearColor(0.5, 0.0, 1.3, 1.0)


    cube = new Cube(gl);

    render()
}

function render(){
    gl.clear(gl.COLOR_BUFFER_BIT)
    cube.render()
}

window.onload = init