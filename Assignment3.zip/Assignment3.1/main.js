
let gl = null;
let cube = null;
let angle = 0;
window.onload = function init() {
    var canvas = document.getElementById("webgl-canvas")
    gl = canvas.getContext("webgl2")
    if (!gl){
        alert ("WebGL 2.0 is not available")
    }

    gl.clearColor(0.9, 0.9, 0.9, 1.0)

    cube = new Cube(gl)
    console.log(canvas.clientHeight)
    render()
}

function render(){
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    angle += 0.5
    cube.MV = rotate(angle, [0.01,0.01,0.01])
    cube.P = perspective(90,1,0,3)
    cube.render()
    requestAnimationFrame(render)
}
