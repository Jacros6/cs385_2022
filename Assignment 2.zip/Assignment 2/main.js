
let gl = null;
let cone = null;

window.onload = function init() {
    var canvas = document.getElementById("webgl-canvas")
    gl = canvas.getContext("webgl2")
    if (!gl){
        alert ("WebGL 2.0 is not available")
    }

    gl.clearColor(0.9, 0.9, 0.9, 1.0)
    cone = new Cone(gl, 1000);

    render()
}

function render(){
    gl.clear(gl.COLOR_BUFFER_BIT)
    cone.render()
}

window.onload = init