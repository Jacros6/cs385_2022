
"use strict";

var gl;
var Sun = undefined
var Earth = undefined
var Moon = undefined
var t = 0.0
var near = 0
var far = 0
var fovy = 0
var aspect = 0
var D = 0

function init() {
    var canvas = document.getElementById("webgl-canvas");
    gl = canvas.getContext("webgl2");

    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    gl.enable(gl.DEPTH_TEST);
   
    // Add your sphere creation and configuration code here
    Sun = new Sphere(20,15)
    Earth = new Sphere(20,15)
    Moon = new Sphere(20,15)



    var yellow = vec4(1.0,1.0,0.0,1.0)

    Sun.radius = 1
    Earth.radius = 0.25
    Earth.orbit = 2
    Moon.radius = 0.10
    Moon.orbit = 0.5
    D = 5.2

    near = 1
    far = near + D
    fovy = 2 * Math.atan(2.6/(near + 2.6))
    aspect = canvas.clientWidth/canvas.clientHeight

    Sun.color = yellow

    requestAnimationFrame(render);

}

function render() {

    // Update your motion variables here
    var ms = new MatrixStack()
    gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);


    var V = translate(0.0, 0.0, -0.5 * (near + far))
    var P = perspective(fovy,aspect,near,far)
    

    ms.load(V)
    // Add your rendering sequence here

    Sun.render()

    ms.push();
    requestAnimationFrame(render);
    //ms.pop()
}

window.onload = init;